function [xdot] = testfunction(x, lambda)
xdot = lambda * x;
end